//Tyler Angelier
//Rick Boles
//Michael Montgomery
//Course Number:(CS4345)
//Semester-Year:(Spring 2018)
//Assignment:(Program 2)

1.) You will need to compile and run Server.java
2.) You will need to compile and run Client.java
3.) To message you can enter your Message in the bottom text field (You can send the message by pressing enter)
4.) To private message start your message with /w followed by the username and the message. EX: /w username this is a PM You can now also select them from a list.
5.) To close the chat window simply press the x button